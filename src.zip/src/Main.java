public class Main {
    public static void main(String[] args) {

        Persona persona = new Persona("Juan", 8);

        System.out.println(persona.getNombre() + " tiene "+persona.getEdad()+" años, por lo que es un -> " + persona.clasificarEdad());

    }
}
