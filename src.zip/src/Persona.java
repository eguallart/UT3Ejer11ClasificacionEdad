public class Persona {
    private String nombre;
    private int edad;

    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }


  //Metodo del clasificador de edad
    public String clasificarEdad() {
        if (edad <= 10) {
            return "niño";
        } else if (edad >= 11 && edad <= 19) {
            return "adolescente";
        } else if (edad >= 20 && edad <= 65) {
            return "adulto";
        } else {
            return "anciano";
        }
    }

    // Metodo para obtener nombre y edad
    public String getNombre() {
        return nombre;
    }
    public int getEdad() {
        return edad;
    }
}
